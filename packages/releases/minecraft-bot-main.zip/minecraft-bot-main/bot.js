const fs = require('fs');
const path = require('path');
const mineflayer = require('mineflayer');

const CONFIG_PATH = path.join(__dirname, 'config.json');

function log(level, msg) {
  const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
  process.stderr.write(`[${ts}] [${level}] ${msg}\n`);
}

function send(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

function loadConfig() {
  try {
    return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch (e) {
    log('ERROR', `Failed to load config: ${e.message}`);
    process.exit(1);
  }
}

let config = loadConfig();
let bot = null;
let connected = false;
let reconnecting = false;
let reconnectAttempts = 0;
let intentionalDisconnect = false;
let lastTransfer = null;
let autoRespawn = false;
let lastHealth = 20;
let debugMode = false;

function createBot() {
  const opts = {
    host: config.host,
    port: config.port || 25565,
    username: config.username || 'Bot',
    version: config.version || false,
    auth: config.auth || 'offline',
    physicsEnabled: false,
    hideErrors: false,
    checkTimeoutInterval: 60000,
    respawn: true
  };

  if (config.auth === 'microsoft' && config.password) {
    opts.password = config.password;
  }

  log('INFO', `Connecting to ${opts.host}:${opts.port} as ${opts.username} (${opts.auth}) v${opts.version || 'auto'}`);

  try {
    bot = mineflayer.createBot(opts);
  } catch (e) {
    log('ERROR', `Failed to create bot: ${e.message}`);
    send({ event: 'error', error: e.message });
    return;
  }

  if (debugMode) {
    bot._client.on('packet', (data, meta) => {
      log('DEBUG', `PACKET: ${meta.name} (${meta.protocol}) ${JSON.stringify(data).slice(0, 500)}`);
    });
  }

  bot.on('login', () => {
    log('INFO', 'Logged in');
    connected = true;
    reconnectAttempts = 0;
    reconnecting = false;
    send({ event: 'connected' });
  });

  bot.on('spawn', () => {
    log('INFO', `Spawned at ${fmtPos(bot.entity.position)}`);
    lastHealth = 20;
    const status = getStatus();
    send({ event: 'spawn', ...status });
  });

  bot.on('chat', (username, message) => {
    if (username === bot.username) return;
    send({ event: 'chat', username, message });
  });

  bot.on('messagestr', (message) => {
    send({ event: 'messagestr', message });
  });

  bot.on('kicked', (reason, loggedIn) => {
    const reasonStr = typeof reason === 'string' ? reason : JSON.stringify(reason);
    log('WARN', `Kicked: ${reasonStr} (loggedIn: ${loggedIn})`);
    connected = false;

    if (intentionalDisconnect) return;

    send({ event: 'kicked', reason: reasonStr });

    const isTransfer = detectTransfer(reasonStr);
    if (isTransfer && lastTransfer) {
      log('INFO', `Transfer detected, reconnecting to ${lastTransfer.host}:${lastTransfer.port}`);
      send({ event: 'transfer', host: lastTransfer.host, port: lastTransfer.port });
      lastTransfer = null;
      setTimeout(() => attemptReconnect(true), 1000);
    } else {
      attemptReconnect(false);
    }
  });

  bot.on('end', (reason) => {
    const reasonStr = typeof reason === 'string' ? reason : JSON.stringify(reason);
    log('INFO', `Disconnected: ${reasonStr}`);
    connected = false;
    bot = null;

    if (intentionalDisconnect) {
      intentionalDisconnect = false;
      return;
    }

    send({ event: 'disconnected', reason: reasonStr });
    attemptReconnect(false);
  });

  bot.on('error', (err) => {
    log('ERROR', `Error: ${err.message}`);
    send({ event: 'error', error: err.message });
  });

  bot._client.on('transfer', (data) => {
    log('INFO', `Transfer packet received: ${data.host}:${data.port}`);
    lastTransfer = { host: data.host, port: data.port };
    send({ event: 'transfer', host: data.host, port: data.port });
  });

  bot.on('health', () => {
    const hp = bot.health;
    if (hp < lastHealth) {
      const dmg = lastHealth - hp;
      log('WARN', `Damage taken: amount=${dmg.toFixed(1)} hp=${hp.toFixed(1)}`);
      send({ event: 'damage', amount: dmg, health: hp });
    }
    lastHealth = hp;
  });

  bot.on('death', () => {
    log('INFO', 'Bot died');
    send({ event: 'died' });
    if (autoRespawn) {
      log('INFO', 'Auto respawn enabled, respawning...');
      setTimeout(() => {
        if (bot) bot.respawn();
      }, 1000);
    }
  });
}

function detectTransfer(reasonStr) {
  const lower = reasonStr.toLowerCase();
  if (lower.includes('internal error') || lower.includes('transfer') || lower.includes('redirect')) {
    return true;
  }
  if (lastTransfer) return true;
  return false;
}

function attemptReconnect(isTransfer) {
  if (reconnecting) return;
  reconnecting = true;

  const maxAttempts = isTransfer ? 999 : (config.reconnect?.attempts || 5);
  const delay = config.reconnect?.delay || 3;

  function tryConnect() {
    if (intentionalDisconnect || reconnectAttempts >= maxAttempts) {
      log('INFO', `Reconnect stopped (attempts: ${reconnectAttempts}/${maxAttempts})`);
      reconnecting = false;
      reconnectAttempts = 0;
      return;
    }

    reconnectAttempts++;
    log('INFO', `Reconnect attempt ${reconnectAttempts}/${maxAttempts} in ${delay}s`);
    send({ event: 'reconnect_attempt', attempt: reconnectAttempts, max: maxAttempts });

    setTimeout(() => {
      if (intentionalDisconnect) {
        reconnecting = false;
        return;
      }
      createBot();
    }, delay * 1000);
  }

  tryConnect();
}

function fmtPos(pos) {
  if (!pos) return 'unknown';
  return `x=${pos.x.toFixed(1)} y=${pos.y.toFixed(1)} z=${pos.z.toFixed(1)}`;
}

function getStatus() {
  if (!bot || !connected) {
    return { connected: false, username: config.username, host: config.host, port: config.port };
  }
  return {
    connected: true,
    username: bot.username,
    host: config.host,
    port: config.port,
    position: bot.entity ? { x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z } : null,
    health: bot.health,
    food: bot.food,
    dimension: bot.game?.dimension,
    gameMode: bot.game?.gameMode,
    serverBrand: bot.game?.serverBrand,
    version: bot.version
  };
}

function handleCommand(line) {
  let msg;
  try {
    msg = JSON.parse(line);
  } catch (e) {
    log('ERROR', `Invalid JSON from stdin: ${line}`);
    return;
  }

  switch (msg.action) {
    case 'connect':
      if (bot && connected) {
        log('WARN', 'Already connected');
        return;
      }
      if (msg.host) config.host = msg.host;
      if (msg.port) config.port = msg.port;
      if (msg.username) config.username = msg.username;
      if (msg.version) config.version = msg.version;
      if (msg.auth) config.auth = msg.auth;
      if (msg.password !== undefined) config.password = msg.password;
      reconnecting = false;
      reconnectAttempts = 0;
      intentionalDisconnect = false;
      createBot();
      break;

    case 'disconnect':
      if (!bot) {
        log('WARN', 'Not connected');
        return;
      }
      intentionalDisconnect = true;
      reconnecting = false;
      reconnectAttempts = 0;
      bot.quit('Disconnected by user');
      bot = null;
      connected = false;
      send({ event: 'disconnected', reason: 'user' });
      break;

    case 'chat':
      if (!bot || !connected) {
        log('WARN', 'Cannot chat: not connected');
        return;
      }
      bot.chat(msg.message);
      log('INFO', `Chat sent: ${msg.message}`);
      break;

    case 'cmd':
      if (!bot || !connected) {
        log('WARN', 'Cannot send command: not connected');
        return;
      }
      const cmd = msg.command.startsWith('/') ? msg.command : `/${msg.command}`;
      bot.chat(cmd);
      log('INFO', `Command sent: ${cmd}`);
      break;

    case 'status':
      send({ event: 'status', ...getStatus() });
      break;

    case 'respawn':
      if (!bot || !connected) {
        log('WARN', 'Cannot respawn: not connected');
        return;
      }
      bot.respawn();
      log('INFO', 'Respawn requested');
      send({ event: 'respawned' });
      break;

    case 'set_autorespawn':
      autoRespawn = !!msg.enabled;
      log('INFO', `Auto respawn: ${autoRespawn ? 'ON' : 'OFF'}`);
      send({ event: 'autorespawn_set', enabled: autoRespawn });
      break;

    case 'set_debug':
      debugMode = !!msg.enabled;
      log('INFO', `Debug mode: ${debugMode ? 'ON' : 'OFF'}`);
      break;

    case 'quit':
      log('INFO', 'Quit requested');
      intentionalDisconnect = true;
      reconnecting = false;
      if (bot) {
        bot.quit('Quit');
        bot = null;
      }
      connected = false;
      process.exit(0);
      break;

    default:
      log('WARN', `Unknown action: ${msg.action}`);
  }
}

process.stdin.setEncoding('utf8');
let buffer = '';
process.stdin.on('data', (chunk) => {
  buffer += chunk;
  const lines = buffer.split('\n');
  buffer = lines.pop();
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed) handleCommand(trimmed);
  }
});

process.stdin.on('end', () => {
  log('INFO', 'stdin closed');
  if (bot) bot.quit('stdin closed');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'SIGTERM received');
  if (bot) bot.quit('SIGTERM');
  process.exit(0);
});

process.on('SIGINT', () => {
  log('INFO', 'SIGINT received');
  if (bot) bot.quit('SIGINT');
  process.exit(0);
});

log('INFO', 'Bot process started');
send({ event: 'ready' });

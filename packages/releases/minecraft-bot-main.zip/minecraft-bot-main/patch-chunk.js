const fs = require('fs');
const path = require('path');

const target = path.join(
  __dirname,
  'node_modules/prismarine-chunk/src/pc/1.18/ChunkColumn.js'
);

if (!fs.existsSync(target)) {
  console.log('[postinstall] prismarine-chunk ChunkColumn.js not found, skipping patch');
  process.exit(0);
}

let src = fs.readFileSync(target, 'utf8');
const original = src;

// All BigInt fixes: wrap pos/minY/worldHeight with Number() in bitwise ops
const patches = [
  // Line 23: numSections
  ['this.numSections = this.worldHeight >> 4',
   'this.numSections = Number(this.worldHeight) >> 4'],

  // Line 155: getBlockStateId
  ['const section = this.sections[(pos.y - this.minY) >> 4]\n      return section ? section.get(toSectionPos(pos, this.minY)) : 0\n    }\n\n    getBlockLight',
   'const section = this.sections[(Number(pos.y) - Number(this.minY)) >> 4]\n      return section ? section.get(toSectionPos(pos, this.minY)) : 0\n    }\n\n    getBlockLight'],

  // Line 170: getBiome
  ['const biome = this.biomes[(pos.y - this.minY) >> 4]\n      return biome ? biome.get(toBiomePos(pos, this.minY)) : 0\n    }\n\n    setBlockType',
   'const biome = this.biomes[(Number(pos.y) - Number(this.minY)) >> 4]\n      return biome ? biome.get(toBiomePos(pos, this.minY)) : 0\n    }\n\n    setBlockType'],

  // Line 183: setBlockStateId
  ['const section = this.sections[(pos.y - this.minY) >> 4]\n      if (section) { section.set(toSectionPos(pos, this.minY), stateId) }',
   'const section = this.sections[(Number(pos.y) - Number(this.minY)) >> 4]\n      if (section) { section.set(toSectionPos(pos, this.minY), stateId) }'],

  // Line 229: setBiome
  ['const biome = this.biomes[(pos.y - this.minY) >> 4]\n      if (biome) { biome.set(toBiomePos(pos, this.minY), biomeId) }',
   'const biome = this.biomes[(Number(pos.y) - Number(this.minY)) >> 4]\n      if (biome) { biome.set(toBiomePos(pos, this.minY), biomeId) }'],

  // Line 293: _loadBlockLightNibbles
  ['const minCY = Math.abs(this.minY >> 4) + 1 // minCY + 1 extra layer below\n      this.blockLightMask',
   'const minCY = Math.abs(Number(this.minY) >> 4) + 1 // minCY + 1 extra layer below\n      this.blockLightMask'],

  // Line 304: _loadSkyLightNibbles
  ['const minCY = Math.abs(this.minY >> 4) + 1 // minCY + 1 extra layer below\n      this.skyLightMask',
   'const minCY = Math.abs(Number(this.minY) >> 4) + 1 // minCY + 1 extra layer below\n      this.skyLightMask'],

  // Line 315: loadSection
  ['const minCY = Math.abs(this.minY >> 4)\n      const raiseUnknownBlock',
   'const minCY = Math.abs(Number(this.minY) >> 4)\n      const raiseUnknownBlock'],

  // Line 377: toBiomePos
  ['return { x: pos.x >> 2, y: ((pos.y - minY) & 0xF) >> 2, z: pos.z >> 2 }',
   'return { x: Number(pos.x) >> 2, y: ((Number(pos.y) - Number(minY)) & 0xF) >> 2, z: Number(pos.z) >> 2 }'],

  // Line 381: toSectionPos
  ['return { x: pos.x, y: (pos.y - minY) & 0xF, z: pos.z }',
   'return { x: Number(pos.x), y: (Number(pos.y) - Number(minY)) & 0xF, z: Number(pos.z) }'],

  // Line 385: getSectionBlockIndex
  ['return (((pos.y - minY) & 15) << 8) | (pos.z << 4) | pos.x',
   'return (((Number(pos.y) - Number(minY)) & 15) << 8) | (Number(pos.z) << 4) | Number(pos.x)'],

  // Line 373: getLightSectionIndex
  ['return Math.floor((pos.y - minY) / 16) + 1',
   'return Math.floor((Number(pos.y) - Number(minY)) / 16) + 1'],

  // Line 102: initialize maxY
  ['const maxY = this.worldHeight + this.minY',
   'const maxY = Number(this.worldHeight) + Number(this.minY)'],
];

let patched = 0;
for (const [old, fix] of patches) {
  if (src.includes(old)) {
    src = src.replace(old, fix);
    patched++;
  }
}

if (patched > 0) {
  fs.writeFileSync(target, src);
  console.log(`[postinstall] Patched ChunkColumn.js (${patched} BigInt fixes applied)`);
} else if (src === original) {
  console.log('[postinstall] ChunkColumn already fully patched');
} else {
  console.log('[postinstall] ChunkColumn patterns not found, skipping');
}

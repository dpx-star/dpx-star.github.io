#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import threading
import queue
import tkinter as tk
from tkinter import font as tkfont
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BOT_SCRIPT = os.path.join(SCRIPT_DIR, 'bot.js')
CONFIG_PATH = os.path.join(SCRIPT_DIR, 'config.json')

BG = '#000000'
FG = '#ffffff'
ACCENT = '#333333'
ACCENT_LIGHT = '#555555'
MONO = 'Courier'
FONT_SIZE = 11


def ts():
    return datetime.now().strftime('%H:%M:%S')


def load_config():
    with open(CONFIG_PATH, 'r') as f:
        return json.load(f)


def save_config(cfg):
    with open(CONFIG_PATH, 'w') as f:
        json.dump(cfg, f, indent=2)


class SettingsOverlay(tk.Frame):
    def __init__(self, parent, on_save):
        super().__init__(parent, bg='#1a1a1a', bd=1, relief='solid')
        self.on_save = on_save
        self.fields = {}
        self._build_ui()
        self.place_forget()

    def _build_ui(self):
        tk.Label(self, text='Settings', bg='#1a1a1a', fg=FG,
                 font=(MONO, 12, 'bold')).pack(pady=(8, 6), padx=10, anchor='w')

        form = tk.Frame(self, bg='#1a1a1a')
        form.pack(fill='x', padx=10)

        defs = [
            ('username', 'Username:', 'entry'),
            ('host', 'Host:', 'entry'),
            ('port', 'Port:', 'spin'),
            ('version', 'Version:', 'entry'),
            ('auth', 'Auth:', 'combo'),
            ('password', 'Password:', 'entry'),
            ('reconnect_attempts', 'Reconnect attempts:', 'spin'),
            ('reconnect_delay', 'Reconnect delay (s):', 'spin'),
        ]

        for i, (key, label, kind) in enumerate(defs):
            tk.Label(form, text=label, bg='#1a1a1a', fg='#aaaaaa',
                     font=(MONO, 10)).grid(row=i, column=0, sticky='w', pady=2)
            if kind == 'entry':
                e = tk.Entry(form, bg=BG, fg=FG, insertbackground=FG,
                             font=(MONO, FONT_SIZE), relief='flat', bd=1,
                             highlightthickness=1, highlightbackground=ACCENT,
                             highlightcolor=ACCENT_LIGHT, show='')
                if key == 'password':
                    e.configure(show='*')
                e.grid(row=i, column=1, sticky='ew', padx=(8, 0), pady=2)
                self.fields[key] = e
            elif kind == 'spin':
                e = tk.Entry(form, bg=BG, fg=FG, insertbackground=FG,
                             font=(MONO, FONT_SIZE), relief='flat', bd=1,
                             highlightthickness=1, highlightbackground=ACCENT,
                             highlightcolor=ACCENT_LIGHT, width=8)
                e.grid(row=i, column=1, sticky='w', padx=(8, 0), pady=2)
                self.fields[key] = e
            elif kind == 'combo':
                c = tk.StringVar()
                cb = tk.OptionMenu(form, c, 'offline', 'microsoft')
                cb.config(bg=BG, fg=FG, activebackground=ACCENT_LIGHT,
                          activeforeground=FG, highlightthickness=0,
                          font=(MONO, FONT_SIZE), relief='flat')
                cb['menu'].config(bg=BG, fg=FG, activebackground=ACCENT_LIGHT,
                                  activeforeground=FG, font=(MONO, FONT_SIZE))
                cb.grid(row=i, column=1, sticky='w', padx=(8, 0), pady=2)
                self.fields[key] = c

        form.grid_columnconfigure(1, weight=1)

        btn_row = tk.Frame(self, bg='#1a1a1a')
        btn_row.pack(fill='x', padx=10, pady=(8, 10))

        tk.Button(btn_row, text='Save', bg=ACCENT, fg=FG, activebackground=ACCENT_LIGHT,
                  activeforeground=FG, font=(MONO, FONT_SIZE), relief='flat',
                  command=self._save).pack(side='right', padx=(4, 0))
        tk.Button(btn_row, text='Cancel', bg=ACCENT, fg=FG, activebackground=ACCENT_LIGHT,
                  activeforeground=FG, font=(MONO, FONT_SIZE), relief='flat',
                  command=self.hide_overlay).pack(side='right')

    def load_fields(self):
        cfg = load_config()
        self.fields['username'].delete(0, 'end')
        self.fields['username'].insert(0, cfg.get('username', ''))
        self.fields['host'].delete(0, 'end')
        self.fields['host'].insert(0, cfg.get('host', ''))
        self.fields['port'].delete(0, 'end')
        port = cfg.get('port')
        self.fields['port'].insert(0, str(port) if port is not None else '')
        self.fields['version'].delete(0, 'end')
        self.fields['version'].insert(0, cfg.get('version', ''))
        self.fields['auth'].set(cfg.get('auth', 'offline'))
        self.fields['password'].delete(0, 'end')
        self.fields['password'].insert(0, cfg.get('password', ''))
        rc = cfg.get('reconnect', {})
        self.fields['reconnect_attempts'].delete(0, 'end')
        self.fields['reconnect_attempts'].insert(0, str(rc.get('attempts', 5)))
        self.fields['reconnect_delay'].delete(0, 'end')
        self.fields['reconnect_delay'].insert(0, str(rc.get('delay', 3)))

    def _save(self):
        port_str = self.fields['port'].get().strip()
        cfg = {
            'username': self.fields['username'].get(),
            'host': self.fields['host'].get(),
            'port': int(port_str) if port_str else None,
            'version': self.fields['version'].get(),
            'auth': self.fields['auth'].get(),
            'password': self.fields['password'].get(),
            'reconnect': {
                'attempts': int(self.fields['reconnect_attempts'].get() or 5),
                'delay': int(self.fields['reconnect_delay'].get() or 3),
            },
        }
        save_config(cfg)
        self.on_save(cfg)
        self.hide_overlay()

    def show_overlay(self):
        self.load_fields()
        self.place(relx=1.0, rely=0.0, anchor='ne', x=-10, y=28)
        self.lift()

    def hide_overlay(self):
        self.place_forget()


class BotConsole:
    def __init__(self, debug=False):
        self.proc = None
        self.running = True
        self.auto_respawn = False
        self.msg_queue = queue.Queue()
        self.debug_mode = debug
        self.debug_file = None
        if debug:
            debug_path = os.path.join(SCRIPT_DIR, 'debug.log')
            self.debug_file = open(debug_path, 'a', buffering=1)
            self._debug_write(f'=== Debug session started ===')

        self.root = tk.Tk()
        self.root.title('Minecraft Bot')
        self.root.configure(bg=BG)
        self.root.minsize(500, 300)
        self.root.geometry('700x500')
        self.root.attributes('-topmost', True)
        self.root.protocol('WM_DELETE_WINDOW', self.on_close)

        mono = tkfont.Font(family=MONO, size=FONT_SIZE)

        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        self.top_bar = tk.Frame(self.root, bg=BG)
        self.top_bar.grid(row=0, column=0, sticky='ew', padx=PADDING, pady=(PADDING, 0))
        self.top_bar.grid_columnconfigure(0, weight=1)

        self.title_label = tk.Label(self.top_bar, text='Minecraft Bot', bg=BG, fg='#666666',
                                     font=(MONO, 9))
        self.title_label.grid(row=0, column=0, sticky='w')

        self.gear_btn = tk.Button(self.top_bar, text='\u2699', bg=BG, fg='#888888',
                                   activebackground=BG, activeforeground=FG,
                                   font=(MONO, 14), relief='flat', bd=0,
                                   command=self.on_gear)
        self.gear_btn.grid(row=0, column=1, sticky='e')

        self.log_frame = tk.Frame(self.root, bg=BG)
        self.log_frame.grid(row=1, column=0, sticky='nsew', padx=PADDING)
        self.log_frame.grid_rowconfigure(0, weight=1)
        self.log_frame.grid_columnconfigure(0, weight=1)

        self.log_text = tk.Text(
            self.log_frame, bg=BG, fg=FG, insertbackground=FG,
            font=mono, wrap='word', state='disabled',
            relief='flat', borderwidth=0, highlightthickness=0,
        )
        self.log_text.grid(row=0, column=0, sticky='nsew')

        self.log_scroll = tk.Scrollbar(self.log_frame, command=self.log_text.yview,
                                        bg=BG, troughcolor=BG)
        self.log_scroll.grid(row=0, column=1, sticky='ns')
        self.log_text.configure(yscrollcommand=self.log_scroll.set)

        self.log_text.tag_configure('timestamp', foreground='#888888')
        self.log_text.tag_configure('info', foreground=FG)
        self.log_text.tag_configure('warn', foreground='#ffcc00')
        self.log_text.tag_configure('error', foreground='#ff4444')
        self.log_text.tag_configure('chat', foreground='#55ccff')
        self.log_text.tag_configure('system', foreground='#44ff44')
        self.log_text.tag_configure('bot', foreground='#aaaaaa')

        self.input_frame = tk.Frame(self.root, bg=BG)
        self.input_frame.grid(row=2, column=0, sticky='ew', padx=PADDING, pady=PADDING)
        self.input_frame.grid_columnconfigure(0, weight=1)

        self.input_var = tk.StringVar()
        self.input_entry = tk.Entry(
            self.input_frame, textvariable=self.input_var,
            bg=BG, fg=FG, insertbackground=FG, font=mono,
            relief='flat', bd=1, highlightthickness=1,
            highlightbackground=ACCENT, highlightcolor=ACCENT_LIGHT,
        )
        self.input_entry.grid(row=0, column=0, sticky='ew')
        self.input_entry.bind('<Return>', self.on_enter)
        self.input_entry.focus_set()

        self.settings_overlay = SettingsOverlay(self.root, self.on_settings_saved)

        self.append_log('Starting bot process...', 'system')
        self.start_bot()
        self.append_log('Type "help" for commands', 'system')

    def on_gear(self):
        if self.settings_overlay.winfo_viewable():
            self.settings_overlay.hide_overlay()
        else:
            self.settings_overlay.show_overlay()
            self.input_entry.focus_set()

    def on_settings_saved(self, cfg):
        self.append_log('Config saved. Restarting...', 'system')
        self.root.after(200, self._restart)

    def append_log(self, text, tag='info'):
        self.msg_queue.put(('log', text, tag))

    def _debug_write(self, text):
        if self.debug_file:
            self.debug_file.write(f'[{ts()}] {text}\n')

    def on_enter(self, event=None):
        line = self.input_var.get().strip()
        self.input_var.set('')
        if not line:
            return
        self.append_log(f'-> {line}', 'system')
        parts = line.split(maxsplit=1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ''

        commands = {
            'help': self.cmd_help,
            'connect': self.cmd_connect,
            'disconnect': self.cmd_disconnect,
            'chat': self.cmd_chat,
            'cmd': self.cmd_cmd,
            'status': self.cmd_status,
            'respawn': self.cmd_respawn,
            'quit': self.cmd_quit,
        }

        if cmd in commands:
            commands[cmd](args)
        else:
            self.append_log(f'Unknown command: {cmd}. Type "help" for commands.', 'error')

    def send_cmd(self, action, **kwargs):
        if self.proc is None or self.proc.poll() is not None:
            self.append_log('Bot process not running', 'error')
            return
        msg = json.dumps({'action': action, **kwargs})
        try:
            self.proc.stdin.write(msg + '\n')
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError) as e:
            self.append_log(f'Failed to send: {e}', 'error')

    def start_bot(self):
        self.proc = subprocess.Popen(
            ['node', BOT_SCRIPT],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=SCRIPT_DIR,
            bufsize=1,
            text=True,
        )
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()

    def stop_bot(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.send_cmd('quit')
                self.proc.wait(timeout=5)
            except Exception:
                self.proc.kill()
        self.proc = None

    def _read_stdout(self):
        while self.running:
            try:
                line = self.proc.stdout.readline()
                if not line:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                    if self.debug_mode:
                        self._debug_write(f'STDOUT: {line}')
                    self._handle_event(msg)
                except json.JSONDecodeError:
                    self.append_log(f'RAW: {line}', 'bot')
                    if self.debug_mode:
                        self._debug_write(f'STDOUT RAW: {line}')
            except Exception:
                break

    def _read_stderr(self):
        while self.running:
            try:
                line = self.proc.stderr.readline()
                if not line:
                    break
                stripped = line.rstrip()
                self.append_log(f'[BOT] {stripped}', 'bot')
                if self.debug_mode:
                    self._debug_write(f'STDERR: {stripped}')
            except Exception:
                break

    def _handle_event(self, msg):
        evt = msg.get('event', 'unknown')
        if evt == 'status':
            self._print_status(msg)
        elif evt == 'spawn':
            pos = msg.get('position', {})
            self.append_log(
                f'SPAWN: pos=({pos.get("x", "?"):.1f}, {pos.get("y", "?"):.1f}, {pos.get("z", "?"):.1f}) '
                f'dim={msg.get("dimension", "?")} hp={msg.get("health", "?")} food={msg.get("food", "?")}',
                'system'
            )
        elif evt == 'chat':
            self.append_log(f'CHAT: <{msg.get("username", "?")}> {msg.get("message", "")}', 'chat')
        elif evt == 'messagestr':
            self.append_log(f'MSG: {msg.get("message", "")}', 'info')
        elif evt == 'kicked':
            self.append_log(f'KICKED: {msg.get("reason", "?")}', 'warn')
        elif evt == 'error':
            self.append_log(f'ERROR: {msg.get("error", "?")}', 'error')
        elif evt == 'disconnected':
            self.append_log(f'DISCONNECTED: {msg.get("reason", "?")}', 'warn')
        elif evt == 'connected':
            self.append_log('CONNECTED', 'system')
        elif evt == 'transfer':
            self.append_log(f'TRANSFER: {msg.get("host", "?")}:{msg.get("port", "?")}', 'warn')
        elif evt == 'reconnect_attempt':
            self.append_log(f'RECONNECT: attempt {msg.get("attempt", "?")}/{msg.get("max", "?")}', 'warn')
        elif evt == 'ready':
            self.append_log('BOT READY', 'system')
        elif evt == 'damage':
            self.append_log(
                f'[WARN] Damage taken: amount={msg.get("amount", 0):.1f} hp={msg.get("health", 0):.1f}',
                'warn'
            )
        elif evt == 'died':
            self.append_log('BOT DIED', 'error')
        elif evt == 'respawned':
            self.append_log('RESPAWNED', 'system')
        elif evt == 'autorespawn_set':
            state = 'ON' if msg.get('enabled') else 'OFF'
            self.append_log(f'AUTO RESPAWN: {state}', 'system')
        else:
            self.append_log(f'{evt}: {msg}', 'info')

    def _print_status(self, msg):
        connected = msg.get('connected', False)
        self.append_log('STATUS:', 'system')
        self.append_log(f'  Connected:  {connected}', 'info')
        self.append_log(f'  Username:   {msg.get("username", "?")}', 'info')
        self.append_log(f'  Server:     {msg.get("host", "?")}:{msg.get("port", "?")}', 'info')
        if connected:
            pos = msg.get('position', {})
            if pos:
                self.append_log(f'  Position:   {pos.get("x", 0):.1f} / {pos.get("y", 0):.1f} / {pos.get("z", 0):.1f}', 'info')
            self.append_log(f'  Health:     {msg.get("health", "?")}', 'info')
            self.append_log(f'  Food:       {msg.get("food", "?")}', 'info')
            self.append_log(f'  Dimension:  {msg.get("dimension", "?")}', 'info')
            self.append_log(f'  GameMode:   {msg.get("gameMode", "?")}', 'info')
            self.append_log(f'  Brand:      {msg.get("serverBrand", "?")}', 'info')
            self.append_log(f'  Version:    {msg.get("version", "?")}', 'info')
        self.append_log(f'  AutoRespawn: {"ON" if self.auto_respawn else "OFF"}', 'info')

    def cmd_help(self, args=''):
        lines = [
            ('Commands:', 'system'),
            ('  connect [host] [port]     - Connect to server', 'info'),
            ('  disconnect                - Disconnect from server', 'info'),
            ('  chat <message>            - Send chat message', 'info'),
            ('  cmd <command>             - Send command (adds / if missing)', 'info'),
            ('  status                    - Show bot status', 'info'),
            ('  respawn                   - Manually respawn', 'info'),
            ('  respawn autorespawnon     - Enable auto respawn on death', 'info'),
            ('  respawn autorespawnoff    - Disable auto respawn', 'info'),
            ('  quit                      - Disconnect and exit', 'info'),
        ]
        for text, tag in lines:
            self.append_log(text, tag)

    def cmd_connect(self, args):
        if not args:
            self.send_cmd('connect')
            return
        parts = args.split()
        kwargs = {}
        if parts[0]:
            kwargs['host'] = parts[0]
        if len(parts) > 1 and parts[1]:
            kwargs['port'] = int(parts[1])
        self.send_cmd('connect', **kwargs)

    def cmd_disconnect(self, args):
        self.send_cmd('disconnect')

    def cmd_chat(self, args):
        if not args:
            self.append_log('Usage: chat <message>', 'error')
            return
        self.send_cmd('chat', message=args)

    def cmd_cmd(self, args):
        if not args:
            self.append_log('Usage: cmd <command>', 'error')
            return
        self.send_cmd('cmd', command=args)

    def cmd_status(self, args):
        self.send_cmd('status')

    def cmd_respawn(self, args):
        sub = args.strip().lower()
        if sub == 'autorespawnon':
            self.auto_respawn = True
            self.send_cmd('set_autorespawn', enabled=True)
            self.append_log('Auto respawn: ON', 'system')
        elif sub == 'autorespawnoff':
            self.auto_respawn = False
            self.send_cmd('set_autorespawn', enabled=False)
            self.append_log('Auto respawn: OFF', 'system')
        elif sub == '':
            self.send_cmd('respawn')
        else:
            self.append_log('Usage: respawn [autorespawnon|autorespawnoff]', 'error')

    def cmd_quit(self, args):
        self.running = False
        self.stop_bot()
        self.root.destroy()

    def on_close(self):
        self.running = False
        self.stop_bot()
        if self.debug_file:
            self._debug_write('=== Debug session ended ===')
            self.debug_file.close()
        self.root.destroy()

    def _restart(self):
        self.running = False
        self.stop_bot()
        if self.debug_file:
            self._debug_write('=== Restarting ===')
            self.debug_file.close()
        self.root.destroy()
        os.execv(sys.executable, [sys.executable] + sys.argv)

    def poll_queue(self):
        while not self.msg_queue.empty():
            try:
                kind, *args = self.msg_queue.get_nowait()
                if kind == 'log':
                    text, tag = args
                    self.log_text.configure(state='normal')
                    self.log_text.insert('end', f'[{ts()}] {text}\n', tag)
                    self.log_text.see('end')
                    self.log_text.configure(state='disabled')
            except queue.Empty:
                break
        if self.running:
            self.root.after(50, self.poll_queue)

    def run(self):
        self.poll_queue()
        self.root.mainloop()


PADDING = 6

if __name__ == '__main__':
    debug = '--debug' in sys.argv
    app = BotConsole(debug=debug)
    app.run()
